Optional Imports
================

WASI originally had its own design for optional imports. To our knowledge,
no toolchains or engines ever implemented it, and it is no longer active.
In the future, optional imports are expected to be a
[feature of the component model].

[feature of the component model]: https://github.com/WebAssembly/component-model/blob/main/design/high-level/UseCases.md#exposing-host-functionality-to-components-as-imports
