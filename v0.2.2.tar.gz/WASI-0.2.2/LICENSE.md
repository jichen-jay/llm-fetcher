Copyright © 2019-2023 the Contributors to the WASI Specification, published
by the [WebAssembly Community Group][cg] under the
[W3C Community Contributor License Agreement (CLA)][cla]. A human-readable
[summary][summary] is available.

[cg]: https://www.w3.org/community/webassembly/
[cla]: https://www.w3.org/community/about/agreements/cla/
[summary]: https://www.w3.org/community/about/agreements/cla-deed/
